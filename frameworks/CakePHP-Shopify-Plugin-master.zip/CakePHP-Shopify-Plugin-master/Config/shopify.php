<?php

$config = array(
                'api_key' => '',
                'shared_secret' => '',
                'scope' => 'write_content,write_products', // <-- change to the scope you need
                'is_private_app' => false
        );
?>
